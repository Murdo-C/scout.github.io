---
layout: page
title: What's New
include_in_header: true
---

### `Initial Release`
# **Version 2021.1**
First release with over 20 iMessage stickers.

<br>

## **Version 2021.2**
Minor design iterations  

<br>

## **Version 2021.2.1**
Four new stickers:
- Ape strong
- We like the stock
- Hold!
- Hold the line

<br>
